UT2004 Ultimate Performance Installer
====================================

INSTALLATION INSTRUCTIONS:
1. Download and extract the ZIP file to any folder
   Example: Desktop or C:\UT2004_Mods\
   
2. Open the extracted folder:
   "UT2004 Ultimate Performance Installer"

3. Run "installer.bat" as Administrator:
   - Right-click the file
   - Select "Run as administrator"

4. Follow the on-screen prompts to configure:
   - Display resolution
   - Frame rate target
   - Audio preferences
   - Mouse input method

NOTES:
- Your original settings will be backed up automatically
- Requires UT2004 already installed on your system
- Administrator rights are necessary for proper installation

After installation, launch UT2004 normally to enjoy your enhanced experience!